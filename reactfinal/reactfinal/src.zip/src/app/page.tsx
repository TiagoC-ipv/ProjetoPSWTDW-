'use client';
import { useState } from 'react';
import Link from 'next/link';

export default function HomePage() {
  const [ativo, setAtivo] = useState('veiculos');
  return (
    <div className="p-8 min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <h1 className="text-4xl font-bold text-center mb-12 text-gray-800">
        Dashboard Oficina Automóvel
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
        <Link href="/veiculos" className="p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all border-2 border-blue-200 hover:border-blue-400">
          <h2 className="text-2xl font-semibold mb-2">🚗 Meus Veículos</h2>
          <p>Gerir veículos associados</p>
        </Link>
        <Link href="/staffagenda" className="p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all border-2 border-green-200 hover:border-green-400">
          <h2 className="text-2xl font-semibold mb-2">🔧 Agenda Mecânico</h2>
          <p>Atualizar estados de serviços</p>
        </Link>
        <Link href="/agendamento" className="p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all border-2 border-purple-200 hover:border-purple-400">
          <h2 className="text-2xl font-semibold mb-2">📅 Marcar Serviço</h2>
          <p>Agendar novo serviço</p>
        </Link>
      </div>
    </div>
  );
}
