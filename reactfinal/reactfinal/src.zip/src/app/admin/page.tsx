export default function AdminPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">Configuração da Oficina</h1>
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-2">Serviços Oferecidos</h2>
        <table className="w-full border">
          <thead>
            <tr className="bg-gray-100 text-left">
              <th className="p-2 border">Serviço</th>
              <th className="p-2 border">Duração</th>
              <th className="p-2 border">Preço</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="p-2 border">Mudança de Óleo</td>
              <td className="p-2 border">30 min</td>
              <td className="p-2 border">60€</td>
            </tr>
          </tbody>
        </table>
        <button className="mt-4 bg-green-600 text-white px-4 py-2 rounded">Criar Novo Serviço</button>
      </section>
    </div>
  );
}