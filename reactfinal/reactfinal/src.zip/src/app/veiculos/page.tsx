'use client';

import { useEffect, useState } from 'react';
import api from '../../lib/api'; // <- caminho relativo

type Veiculo = {
  _id?: string;
  marca: string;
  modelo: string;
  matricula: string;
  ano: number;
};

export default function VeiculosPage() {
  const [veiculos, setVeiculos] = useState<Veiculo[]>([]);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState('');

  useEffect(() => {
    const fetchVeiculos = async () => {
      try {
        const res = await api.get('/veiculos'); // http://localhost:4000/api/veiculos
        setVeiculos(res.data);
      } catch (err) {
        setErro('Erro ao carregar veículos');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchVeiculos();
  }, []);

  if (loading) return <p className="text-white p-8">A carregar veículos...</p>;
  if (erro) return <p className="text-red-400 p-8">{erro}</p>;

  return (
    <main className="min-h-screen bg-[#0f172a] text-white p-8">
      <h1 className="text-3xl font-bold mb-6">Meus Veículos</h1>

      {veiculos.length === 0 ? (
        <p>Sem veículos na base de dados.</p>
      ) : (
        <div className="space-y-4">
          {veiculos.map((v) => (
            <div
              key={v._id || v.matricula}
              className="bg-slate-800 border border-blue-500 rounded-xl p-4"
            >
              <h2 className="text-xl font-semibold">
                {v.marca} {v.modelo} ({v.ano})
              </h2>
              <p className="text-slate-300">Matrícula: {v.matricula}</p>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}
