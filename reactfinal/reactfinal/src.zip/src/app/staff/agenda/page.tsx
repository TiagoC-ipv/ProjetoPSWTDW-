'use client';
import { useState } from 'react';

export default function StaffAgendaPage() {
  const [status, setStatus] = useState('Pendente');

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Agenda Diária</h1>
      <div className="border p-4 rounded-lg bg-blue-50">
        <h3 className="font-bold">Marcação #1234</h3>
        <p>Veículo: AA-00-BB | Serviço: Revisão Geral</p>
        <p>Estado Atual: <span className="font-semibold text-orange-600">{status}</span></p>
        <div className="mt-4 flex gap-2">
          <button onClick={() => setStatus('Em curso')} className="bg-orange-500 text-white px-3 py-1 rounded">Iniciar</button>
          <button onClick={() => setStatus('Concluída')} className="bg-green-600 text-white px-3 py-1 rounded">Concluir</button>
        </div>
      </div>
    </div>
  );
}