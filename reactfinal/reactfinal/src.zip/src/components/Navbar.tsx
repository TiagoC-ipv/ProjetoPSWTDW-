import Link from 'next/link';

export default function Navbar() {
  return (
    <nav className="flex gap-6 p-4 bg-gray-800 text-white">
      <Link href="/veiculos" className="hover:text-blue-400">Meus Veículos</Link>
      <Link href="/agendamento" className="hover:text-blue-400">Marcar Serviço</Link>
      <Link href="/staff/agenda" className="hover:text-blue-400">Agenda Mecânico</Link>
      <Link href="/admin" className="hover:text-blue-400">Admin Oficina</Link>
    </nav>
  );
}